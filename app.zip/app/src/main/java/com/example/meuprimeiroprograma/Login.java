package com.example.meuprimeiroprograma;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    EditText username, password;
    Button bt_login;

    DBHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new DBHelper(this);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        bt_login = (Button)findViewById(R.id.bt_login);
        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("")){
                    Toast.makeText(Login.this,"Username nao inserido, tente novamente",Toast.LENGTH_SHORT).show();
                }
                else if(pass.equals("")){
                    Toast.makeText(Login.this,"Password nao inserido, tente novamente",Toast.LENGTH_SHORT).show();
                }
                else{
                   String res = db.ValidarLogin(user,pass);
                   if(res.equals("OK")){
                       Toast.makeText(Login.this,"Login OK",Toast.LENGTH_SHORT).show();
                       Intent i = new Intent(Login.this, CriarAlunos.class);
                       startActivity(i);
                   }
                   else{
                       Toast.makeText(Login.this,"Login errado, tente novamente",Toast.LENGTH_SHORT).show();
                   }

                }

            }
        });


    }
}
