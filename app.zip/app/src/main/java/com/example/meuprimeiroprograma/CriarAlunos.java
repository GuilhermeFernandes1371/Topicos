package com.example.meuprimeiroprograma;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class CriarAlunos extends AppCompatActivity {

    private EditText nome;
    private EditText cpf;
    private AlunoDAO dao;
    private Aluno aluno = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criar_alunos);

        this.nome = findViewById(R.id.name);
        this.cpf = findViewById(R.id.cpf);

        this.dao = new AlunoDAO(this);
        Intent it = getIntent();
        if(it.hasExtra("aluno")){
            aluno = (Aluno) it.getSerializableExtra("aluno");
            nome.setText(aluno.getNome());
            cpf.setText(aluno.getCpf());

        }
    }

    public void salvar(View view) {
        if(aluno == null) {
            Aluno aluno = new Aluno(this.nome.getText().toString(), this.cpf.getText().toString());
            long idALuno = this.dao.create(aluno);

            Toast.makeText(this, "Aluno inserido com id: " + idALuno, Toast.LENGTH_SHORT).show();
            Intent i = new Intent(CriarAlunos.this, ListarAlunos.class);
            startActivity(i);
        }else{
            aluno.setNome(nome.getText().toString());
            aluno.setCpf(nome.getText().toString());
            dao.atualizar(aluno);
            Toast.makeText(this, "Aluno foi atualizado", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(CriarAlunos.this, ListarAlunos.class);
            startActivity(i);
        }
    }



}
