package com.topicos.appmapas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;




public class FormActivity extends AppCompatActivity {


    EditText editNome, editVeiculo;
    Button bt_Marca;
    String conc = " ";



    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_form);


        editNome =  findViewById(R.id.editNome);
        editVeiculo =  findViewById(R.id.editVeiculo);

        bt_Marca = (Button)findViewById(R.id.bt_Marca);
        bt_Marca.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                String user = editNome.getText().toString();
                String pass = editVeiculo.getText().toString();
                conc = user + " " + pass;

                if(user.equals("")){
                    Toast.makeText(FormActivity.this,"Nome nao inserido, tente novamente",Toast.LENGTH_SHORT).show();

                }
                else if(pass.equals("")){
                    Toast.makeText(FormActivity.this,"Veículo nao inserido, tente novamente",Toast.LENGTH_SHORT).show();

                }
                Intent i = new Intent(FormActivity.this, ProviderV2GPS.class);
                i.putExtra("MENSSAGEM",conc);
                startActivity(i);



            }
        });




    }



}
